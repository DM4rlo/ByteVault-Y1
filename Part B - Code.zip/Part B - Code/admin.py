
class Admin:
    
    def __init__(self, fname, lname, address, user_name, password, full_rights):
        self.fname = fname
        self.lname = lname
        self.address = address
        self.user_name = user_name
        self.password = password
        self.full_admin_rights = full_rights
        
    def clear(self):
        print("\n" * 80) 
    
    def update_first_name(self, fname):
        self.fname = fname
    
    def update_last_name(self, lname):
        self.lname = lname
                
    def get_first_name(self):
        return self.fname
    
    def get_last_name(self):
        return self.lname
        
    def update_address(self, addr):
        self.address = addr
    
    def set_username(self, uname):
        self.user_name = uname
        
    def get_username(self):
        return self.user_name
        
    def get_address(self):
        return self.address      
    
    def update_password(self, password):
        self.password = password
    
    def get_password(self):
        return self.password
    
    def set_full_admin_right(self, admin_right):
        self.full_admin_rights = admin_right

    def has_full_admin_right(self):
        return self.full_admin_rights
    
    
    def print_admin_details(self):
        print("First name: %s" %self.fname)
        print("Last name:  %s" %self.lname)
        print("Address:    %s" %self.address[0])
        print(" %s" %self.address[1])
        print(" %s" %self.address[2])
        print(" %s" %self.address[3])
        print("Username: %s" %self.user_name)
        print("Elevated Account Privileges: %s" %self.full_admin_rights)
        print(" ")
    
    
    def updating_admin_account(self):
        print ("\n Your Update Options Are:")
        print ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print ("1) Change First Name")
        print ("2) Change Last Name")
        print ("3) Change Address")
        print ("4) Change Username")
        print ("5) Change Password")
        print ("6) Request Authorization Amendment")
        print ("7) Check Account Privileges")
        print ("8) Display your Account Details")
        print ("9) Back")
        print (" ")
        option = int(input ("Choose your option: "))
        self.clear()
        return option
    
    def update_admin_options(self):
        loop = 1
        while loop == 1:
            choice = self.updating_admin_account()
            
            # Change First Name
            if choice == 1:
                fname = input("Enter your new first name: ")
                self.update_first_name(fname)
                self.clear()
                print("Your first name has been updated successfully")
                
            
            # Change Last Name 
            elif choice == 2:
                lname = input("Enter your new last name: ")
                self.update_last_name(lname)
                self.clear()
                print("Your last name has been updated successfully")
                
            
            # Change Address
            elif choice == 3:
                print("New Address Should Consist of 4 Different Elements Seperated by Spaces")
                addr = input("Enter your new address: ")
                self.update_address(addr)
                self.clear()
                print("Your last name has been updated successfully")
            
            
            # Change Username
            elif choice == 4:
                uname = input("Enter new username: ")
                self.set_username(uname)
                self.clear()
                print("Your username has been updated successfully")
                
            
            # Change Password
            elif choice == 5:
                password = input("Enter new password: ")
                self.update_password(password)
                self.clear()
                print("Your password has been updated successfully")
                
            
            # Authorization Request
            elif choice == 6:
                print("Would you like to elevate your account privileges or")
                print("restrict them further?")
                admin_right = input("To elevate type 'yes' else type 'no': ")
                self.clear()
                
                # Increases privileges
                if admin_right == "yes":
                    self.set_full_admin_right(admin_right=True)
                    print("Your Request will be processed for evaluation, Please stand by.")
                
                # Increases privileges
                elif admin_right == "no":
                    self.set_full_admin_right(admin_right=False)
                    print("Your Request will be processed for evaluation, Please stand by.")
            
            # Check Account privileges 
            elif choice == 7:
                # returns bool value for examination
                self.has_full_admin_right()
                
                # if account has elevated privileges
                if self.full_admin_rights == True:
                    print("You account has elevated privileges")
                
                # if account doesn't have elevated privileges
                elif self.full_admin_rights == False:
                    print("Your account Doesn't have elevated privileges")
                
            elif choice == 8:
                self.print_admin_details()
                
            
            
            # Exit Admin Update Menu
            elif choice == 9:
                loop = 0
        self.clear()
        print("Exited update admin account operations")
                
            
