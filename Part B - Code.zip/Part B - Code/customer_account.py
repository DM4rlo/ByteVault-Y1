bank_types_list = []

class CustomerAccount:
    def __init__(self, fname, lname, address, account_no, balance1, balance2, open_accounts):
        self.fname = fname
        self.lname = lname
        self.address = address
        self.account_no = account_no
        self.balance1 = float(balance1)
        self.balance2 = float(balance2)
        self.open_accounts = open_accounts
        self.bank_types_list = []
        self.load_bank_types()
    
    
    def load_bank_types(self):
        
# Create Types of Bank Accounts**************************************************************************************************************************************
        for e in self.open_accounts:
            if e == "Current_Account":
                current_acc = (["Current Account", "Contactless Payments", "Adjustable Overdraft Available", "Everyday Offers (15% Cashback in certain stores)", "Access to our Mobile App", "%0.10", 1500.00, "£0", 0.00])
                self.bank_types_list.append(current_acc)

                
            if e == "Premium_Account":
                # Premium Account Creation 
                premium_acc = (["Premium Account", "Family Travel insurance", "AA Breakdown Cover", "Mobile Phone Insurance ", "Everyday Offers", "%0.85", 4500.00, "£21", 0.00])
                self.bank_types_list.append(premium_acc)
        
        
            if e == "Student_Account":
                # Student Account Creation
                student_acc = (["Student Account", "0% interest on overdraft for course duration", "Discounts on Travel Services", "Access to our Mobile App", "Contactless Payments", "%0.02", 1000.00, "£0", 0.00])
                self.bank_types_list.append(student_acc)
                
                
            if e == "Business_Account":
                # Business Account Creation
                business_acc = (["Business Account", "Expert Support & Aid from us", "Business Insurance", "Access to Accounting Software", "N/a", "%0.50", 15000.00, "£45", 0.00])
                self.bank_types_list.append(business_acc)
                
    
    
    
    def clear(self):
        print("\n" * 80)
    
    def update_first_name(self, fname):
        self.fname = fname
    
    def update_last_name(self, lname):
        self.lname = lname
                
    def get_first_name(self):
        return self.fname
    
    def get_last_name(self):
        return self.lname
        
    def update_address(self, addr):
        self.address = addr
        
    def get_address(self):
        return self.address
    
    def get_overdrafts(self):
        pass
    
# Balance 1**************************************************************************************************
    def deposit(self, amount):
        self.balance1+=amount
        
    def withdraw(self, amount):
        self.balance1-=amount
        
    def print_balance1(self):
        print("\n Your {} Balance is £{}" .format(self.open_accounts[0], self.balance1))
        
    def get_balance1(self):
        return self.balance1
    
# Overdraft**************************************************************************************************
    def withdraw_overdraft(self, amount):
        self.bank_types_list[0][6]-=amount # (Decreases Available Amount)
        self.bank_types_list[0][8]+=amount # Increases Used Amount (Outstanding)
        
    def deposit_overdraft(self, amount):
        self.bank_types_list[0][6]+=amount # (Increases Available Amount)
        self.bank_types_list[0][8]-=amount # (Decreases Used Amount (Outstanding)

# Balance 2**************************************************************************************************
    def deposit2(self, amount):
        self.balance2+=amount
        
    def withdraw2(self, amount):
        self.balance2-=amount
        
    def print_balance2(self):
        print("\n Your {} Balance is £{}" .format(self.open_accounts[1], self.balance2))
        
    def get_balance2(self):
        return self.balance2
    
# Overdraft 2************************************************************************************************
    def withdraw_overdraft2(self, amount):
        self.bank_types_list[1][6]-=amount # (Decreases Available Amount)
        self.bank_types_list[1][8]+=amount # Increases Used Amount (Outstanding)        

    def deposit_overdraft2(self, amount):
        self.bank_types_list[1][6]+=amount # (Increases Available Amount)
        self.bank_types_list[1][8]-=amount # (Decreases Used Amount (Outstanding)
        
    
# Overdraft Options******************************************************************************************
    def overdraft_option(self):
        
        print("Overdraft Options Below:"      )
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("1) Withdraw"                   )
        print("2) Deposit (Return whats owed)")
        print("3) Check Whats Available"      )
        print("4) Return to Customer Menu")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print(" ")
        opt = int(input("Choose an option: "))
        self.clear()
        return opt 
    
    
#************************************************************************************************************   
    
    def get_account_no(self):
        return self.account_no
    
    def account_menu(self):
        print ("\n Your Transaction Options Are:")
        print ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print ("1) Deposit Money")
        print ("2) Withdraw Money")
        print ("3) Overdraft Options")
        print ("4) Check Balances")
        print ("5) Update Customer Name")
        print ("6) Update Customer Address")
        print ("7) Show Customer Details")
        print ("8) Types of Bank Accounts (You have)")
        print ("9) Back")
        print (" ")
        option = int(input ("Choose your option: "))
        self.clear()
        return option
    
    def print_details(self):
        print("Customer Details Below: ")
        print("------------------------")
        print("First name: %s" %self.fname)
        print("Last name:  %s" %self.lname)
        print("Account No: %s" %self.account_no)
        print("Address: ")    
        print("- %s" %self.address[0])
        print("- %s" %self.address[1])
        print("- %s" %self.address[2])
        print("- %s" %self.address[3])
        print("Current Open Bank Accounts: ")
        print(" ")
        print("- {}, Balance: £{}, Overdraft Available: £{}" .format(self.open_accounts[0], self.balance1, self.bank_types_list[0][6]))
        print("- Used Overdraft: £{} from {}" .format(self.bank_types_list[0][8], self.open_accounts[0]))
        print(" ")
        print("- {}, Balance: £{}, Overdraft Available: £{}" .format(self.open_accounts[1], self.balance2, self.bank_types_list[1][6]))
        print("- Used Overdraft: £{} from {}" .format(self.bank_types_list[1][8], self.open_accounts[1]))
        print(" ")

    def run_account_options(self):
        loop = 1
        while loop == 1:
            choice = self.account_menu()
            
            # Deposit Process
            if choice == 1:
                print("Would you like to deposit into your {} or your {} " .format(self.open_accounts[0], self.open_accounts[1]))
                response = input("Please input '1' for your {} or '2' for  your {}: " .format(self.open_accounts[0], self.open_accounts[1]))
                self.clear()
                
                # Decision is made
                if response == 1:
                    amount=float(input("\n Please enter amount to be deposited: "))
                    self.deposit(amount)
                    self.clear()
                    self.print_balance1()
                elif response == 2:
                    amount=float(input("\n Please enter amount to be deposited: "))
                    self.deposit2(amount)
                    self.clear()
                    self.print_balance2()
                
                else:
                    print("must be an option presented")
                
            # Withdraw Process
            elif choice == 2:
                print("Would you like to withdraw from your {} or {} " .format(self.open_accounts[0], self.open_accounts[1]))
                response = input("Please input '1' for your {} or '2' for  your {}: " .format(self.open_accounts[0], self.open_accounts[1]))
                self.clear()
                
                # Decision is made
                if response == 1:
                    amount=float(input("\n Please enter amount to be withdrawn: "))
                    self.withdraw(amount)
                    self.clear()
                    self.print_balance1()
                elif response == 2:
                    amount=float(input("\n Please enter amount to be withdrawn: "))
                    self.withdraw2(amount)
                    self.clear()
                    self.print_balance2()
                    
                else:
                    print("must be an option presented")
                    
            # Overdraft options               
            elif choice == 3:
                loop = 1
                while loop == 1:
                    opt = self.overdraft_option()
                
                    # Withdraw from overdraft (Account 1 or 2)
                    if opt == 1:
                        print("Would you like to withdraw overdraft from your {} or {} " .format(self.open_accounts[0], self.open_accounts[1]))
                        response = int(input("Please input '1' for your {}  or '2' for  your {}: " .format(self.open_accounts[0], self.open_accounts[1])))
                        self.clear()
                
                        # Decision is made for which account is interacted with
                        if response == 1:
                            amount=float(input("\n Please enter amount to be withdrawn: "))
                            self.withdraw_overdraft(amount)
                            self.clear()
                            print("Withdraw Successful")
                        elif response == 2:
                            amount=float(input("\n Please enter amount to be withdrawn: "))
                            self.withdraw_overdraft2(amount)
                            self.clear()
                            print("Withdraw Successful")
                            
                        else:
                            print("must be an option presented")
                    
        
                    # Deposit into overdraft
                    elif opt == 2:
                        print("Would you like to deposit into overdraft from your {} or {} " .format(self.open_accounts[0], self.open_accounts[1]))
                        response = int(input("Please input '1' for your {}  or '2' for  your {}: " .format(self.open_accounts[0], self.open_accounts[1])))
                        self.clear()
                        
                        # Decision is made for which account is interacted with
                        if response == 1:
                            amount=float(input("\n Please enter amount to be deposited: "))
                            self.deposit_overdraft(amount)
                            self.clear()
                            print("Deposit Successful")
                        elif response == 2:
                            amount=float(input("\n Please enter amount to be deposited: "))
                            self.deposit_overdraft2(amount)
                            self.clear()
                            print("Deposit Successful")
                            
                        else:
                            print("must be an option presented")

    
                    # Check Amount Available
                    elif opt == 3:
                        print("Overdrafts Found Below:")
                        print("~~~~~~~~~~~~~~~~~~~~~~~")
                        print("Available overdraft for your {} is £{}".format(self.open_accounts[0], self.bank_types_list[0][6]))
                        print("Outstanding Overdraft: £{}" .format(self.bank_types_list[0][8]))
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print("Available overdraft for your {} is £{}".format(self.open_accounts[1], self.bank_types_list[1][6]))
                        print("Outstanding Overdraft: £{}" .format(self.bank_types_list[1][8]))
                        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                        print(" ")
                        
                        
                    # Return to Customer Menu
                    elif opt == 4:
                        loop = 0
                        
                    else:
                        print("must be an option presented")
                    
                self.clear()    
                
            
            # Check balance
            elif choice == 4:
                print("Would you like to check balance for your {} or {}?" .format(self.open_accounts[0], self.open_accounts[1]))
                response = input("Please input '1' for your {}  or '2' for  your {} : " .format(self.open_accounts[0], self.open_accounts[1]))
                self.clear()
                
                # Decision is made 
                if response == 1:
                    self.print_balance1()
                elif response == 2:
                    self.print_balance2()
                    
                else:
                    print("must be an option presented")
                
            # Update Customer Name
            elif choice == 5:
                fname=input("\n Enter new customer first name: ")
                self.update_first_name(fname)
                
                sname = input("\nEnter new customer last name: ")
                self.update_last_name(sname)
                
                self.clear()
                print("Data has been updated")

            # Update Customer Address
            elif choice == 6:
                print("New Address Should Consist of 4 Different Elements Seperated by Spaces")
                newAddr=input("\n Enter new customer address: ")
                self.update_address(newAddr)
                self.clear()
                print("Data has been updated")
            
            # Display Customer Detials
            elif choice == 7:
                self.print_details()
            
            # Show Current Bank Accounts
            elif choice == 8:
                i = 0
                for e in self.bank_types_list:
                    print("Bank Account %s: " %i)
                    print("-------------------------------------------------")
                    print("Account Type:        %s" %self.bank_types_list[i][0])
                    print("Account Perks: ")
                    print("* %s" %self.bank_types_list[i][1])
                    print("* %s" %self.bank_types_list[i][2])
                    print("* %s" %self.bank_types_list[i][3])
                    print("* %s" %self.bank_types_list[i][4])
                    print("Interest Rate:       %s" %self.bank_types_list[i][5])      
                    print("Available Overdraft: £{}" .format(self.bank_types_list[i][6]))
                    print("Monthly Fee:         %s" %self.bank_types_list[i][7])
                    print("-------------------------------------------------")
                    print("\n")
                    i = i + 1
                
            
            # Exit Customer Menu
            elif choice == 9:
                loop = 0
                
            else:
                print("Please choose one of options presented")
                
        self.clear()
        print ("\n Exit account operations")
        

